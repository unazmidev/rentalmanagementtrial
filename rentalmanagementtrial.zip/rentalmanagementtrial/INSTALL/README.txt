This project was created by ronald ngoda
phone:+2540708344101
email:ronniengoda@gmail.com
website:www.ronaldngoda.rf.gd

---HOW TO INSTALL---
After extracting the zip file ,find the folder names INSTALL in this folder you will find the file named rentalmanagement.SQL
go to your phpmyadmin and create a new database called rentalmanagent and import the file named rentalmanagement.SQL to create all the tables.....
After importing all the tables you can now run the project in your favourite browser ,create an account and experience the system!!......